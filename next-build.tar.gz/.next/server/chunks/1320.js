"use strict";exports.id=1320,exports.ids=[1320],exports.modules={54122:(e,t,a)=>{a.d(t,{bF:()=>categoryNodes,$:()=>categorySlug});let r=[{name:"Для крупной техники",children:[{name:"Запчасти для стиральных машин",children:["Аксессуары","Амортизаторы","Амортизирующие подставки","Баки, полубаки, барабаны","Болты крепления","Вентиляторы","Втулки амортизатора","Двигатели (моторы)","Держатели шланга","Замки люка (двери)","Клапаны","Кнопки вкл./выкл.","Конденсаторы","Корпусные детали","Крепежные элементы","Крестовины","Люки и обрамления","Манжеты (резина) люка","Модули (платы) управления","Нагреватели сушки","Насосы (помпы)","Ножки","Основание клавиш управления","Патрубки","Петли люка (двери)","Подшипники","Порошкоприемники (дозаторы)","Прокладки","Противовесы","Пружины бака","Ребра (активаторы) барабана","Редукторы","Реле уровня воды (прессостаты)","Ремни","Ремонтные наборы","Ручки люка, крючки, защелки","Ручки переключения","Сальники","Сетевые фильтры","Смазки для сальников и подшипников","Средства по уходу за стиральными машинами","Стекло люка","Суппорты (блоки подшипников)","Таймеры, переключатели, селекторы","Таходатчики (датчики холла)","Термосенсоры","Термостаты","ТЭНы","Уплотнители бака","Фильтры насоса (помпы)","Фланец барабана (опора)","Хомуты","Шкивы","Шланги сливные, заливные","Щетки двигателя (мотора)","Электропроводка"]},{name:"Запчасти для холодильников",children:["Аксессуары","Втулки","Выключатели света","Генераторы льда","Датчики, сенсоры","Двери (дверцы)","Дверные полки","Двигатели вентилятора","Двигатели заслонки","Декоративные элементы","Заглушки, панели, накладки дверей холодильников","Испарители","Клапаны","Клапаны Шредера","Компрессоры","Корпусные детали","Крепежные элементы","Крепления фасада дверей","Крышки фреш зоны","Лампы освещения","Лотки, формы, емкости","Модули (платы) управления","Направляющие","Ножки","Обрамление полки","Панели ящика","Петли двери","Плафоны","Поддоны","Полки","Провода","Пусковые реле","Ручки двери","Ручки терморегулятора","Средства для холодильников и морозильных камер","Таймеры","Термостаты","Тэны оттайки","Уплотнительная резина","Фильтр-осушитель фреоновый","Фильтры","Фреон","Эмблемы","Ящики"]},{name:"Запчасти для плит и духовок",children:["Аксессуары","Блоки розжига","Выключатели","Газовые трубки","Двери и стекла","Двигатели и вентиляторы","Декоративные кнопки, клавиши, наклейки","Держатели стекол","Дефлекторы двери и панели","Замки блокировки двери","Индикаторы","Клапаны","Клеммные колодки (клеммные блоки)","Конфорки","Корпусные детали","Краны газовые","Крышки верхние","Лампочки духовки","Лимбы (диски), пружины","Модули (платы) управления","Направляющие","(Держатели) противней","Передние панели","Переключатели","Петли, завесы, крепления","Плафоны ламп","Поверхности","Провода и разъемы","Противни и решетки для духовки","Рассекатели и крышки","Решетки на поверхность","Ручки двери","Ручки регулировки","Свечи поджига","Средства для чистки стеклокерамики","Скребки для плит и духовок","Таймеры","Термометры и термощупы","Термопара","Термостаты","Толкатели и держатели кнопок","ТЭНы для духовок и грилей","ТЭНы и спирали для электроплит","Уплотнители (прокладки)","Уплотнители двери","Форсунки (инжекторы)"]},{name:"Запчасти для газовых котлов",children:["Блоки розжига","Вентиляторы, трубки Вентури","Воздушные клапаны, воздухоотводчики","Газовые горелки и форсунки","Газовые клапаны","Гидравлические группы, узлы","Датчики и реле давления воды","Датчики температуры","Дымоходы и коаксиальные системы","Изоляционные панели, блоки и кольца","Кабели и комплекты электроподключений","Корпусные детали","Краны подпитки, слива","Манометры и термометры","Мембраны","Предохранительные клапаны","Программаторы, хронотермостаты и внешние датчики","Расширительные баки","Реле дифференциального давления воздуха","Реле протока воды и датчики Холла","Ручки, кнопки и панели управления","Средства для обслуживания котлов","Теплообменники","Термопары и зажигатели пилотных горелок","Термостаты безопасности и регулировки","Трехходовые клапаны, сервоприводы","Трубки, шланги, сальники","Уплотнения, скобы и прочее","Циркуляционные насосы и корпуса","Электроды розжига и ионизации","Электронные платы, регуляторы и другие электронные компоненты"]},{name:"Запчасти для газовых колонок",children:["Водная арматура, мембраны","Газовая арматура, форсунки","Датчики, микропереключатели","Ручки, элементы корпуса","Теплообменники, скобы, кольца","Электроды, термопары, розжигатели","Электронные платы управления, блоки питания, розжига"]},{name:"Запчасти для электрических котлов",children:["Блоки тэнов","Воздушные и предохранительные клапаны","Датчики давления и протока воды","Датчики и ограничители температуры","Манометры","Нагревательные узлы","Расширительные баки","Узлы мощности","Уплотнения, трубки и другое","Циркуляционные насосы","Электронные платы и панели управления"]},{name:"Запчасти для водонагревателей",children:["Аксессуары","Аноды","Выключатели","Датчики (сенсоры) температуры","Лампочки индикации","Нижние крышки","Платы управления","Предохранительные клапаны (клапаны давления)","Прокладки фланца","Ремонтные наборы","Ручки регулировки","Сетевые шнуры","Термостаты","Тэны","Фланцы"]},{name:"Запчасти для посудомоечных машин",children:["Аксессуары","Выключатели","Датчики","Держатели разбрызгивателя","Держатели стаканов, чашек","Дозаторы","Замок (блокиратор) двери","Ионизаторы воды (декальцификаторы)","Клапаны подачи воды","Колесо (ролики) ящика","Корзины","Корпусные детали","Крепежные элементы","Крыльчатки (улитки) насоса","Модули (платы) управления","Насосы (помпы)","Ножки","Панели управления","Патрубки","Петли двери","Прокладки и уплотнители","Пружины двери","Разбрызгиватели (импеллеры)","Распределители воды","Реле уровня воды (прессостаты)","Ручки двери","Ручки переключения","Сальники","Сетевые фильтры","Соль","Средства по уходу за посудомоечными машинами","Теплообменники","Тэны","Тяги (тросы) двери","Уплотнители двери","Фильтры","Шланги сливные, заливные"]},{name:"Запчасти к сушильным машинам",children:["Аксессуары","Баки, барабаны","Втулки","Датчики","Двери (люки) и обрамления","Двигатели (моторы)","Замки люка (двери)","Клапаны","Кнопки вкл./выкл.","Компрессоры","Конденсаторы","Короны","Корпусные детали","Крыльчатки","Модули (платы) управления","Насосы (помпы)","Ножки","Опора барабана","Петли люка (двери)","Подшипники","Ребра (активаторы) барабана","Ремни","Роллеры","Ручки люка, крючки, защелки","Сетевые фильтры","Стекла двери","Тэны","Термостаты","Уплотнители","Фильтры","Шкивы","Шланги","Щетки двигателя (мотора)"]},{name:"Запчасти для вытяжек",children:["Аксессуары","Блоки управления","Двигатели","Крыльчатки","Лампы подсветки","Платы управления","Фильтры"]}]},{name:"Для кухонной техники",children:[{name:"Аксессуары для приготовления пищи",children:["Аксессуары для микроволновок","Ведра для хлебопечек","Насадки для блендеров","Насадки и терки для мясорубки","Пластины для грилей","Противни и решетки для духовок","Терки (барабанчики, диски, вставки) для кухонных комбайнов","Чаши для мультиварок"]},{name:"Запчасти для кухонных комбайнов",children:["Аксессуары","Венчики","Вставки (насадки), диски","Двигатели","Держатели терок","Крышки корпуса","Крышки на чашу","Насадки для мясорубки","Насадки-соковыжималки и их запчасти","Ножи","Платы управления","Прокладки","Разное","Редукторы","Ремни","Толкатели","Цитрус-пресс","Чаши","Шестерни и муфты","Шкивы","Штоки"]},{name:"Запчасти для блендеров и миксеров",children:["Блендерные ножи и насадки","Венчики","Вставки, терки, диски","Держатели вставок","Измельчители","Крышки для чаши","Мерные стаканы","Моторная группа","Муфты","Ножи","Основание чаши","Платы управления","Прочие детали","Редукторы к венчику","Редукторы к чаше","Толкатели","Уплотнители","Чаши","Шестерни","Штоки"]},{name:"Запчасти для микроволновых печей",children:["Аксессуары","Двери","Двигатели обдува","Двигатели поддона","Колпачки на магнетрон","Конденсаторы и диоды","Крышки для микроволновок","Крючок двери","Куплеры","Лампочки","Магнетроны","Микропереключатели (микрки, концевики)","Панели управления","Платы управления","Предохранители","Роллеры","Ручки микроволновки","Слюда","Средства для микроволновок","Таймеры","Тарелки","Трансформаторы","Тэны"]},{name:"Запчасти для мясорубок",children:["Гайки корпуса","Двигатели","Держатели тубуса","Кнопки","Лотки","Муфты","Насадки-соковыжималки и их запчасти","Насадки, барабанчики (терки)","Ножи","Платы управления (модули)","Редукторы","Решетки","Толкатели","Тубусы","Шестерни","Шнеки"]},{name:"Запчасти для кофеварок и кофемашин",children:["Аксессуары","Бойлеры, ТЭНы, термоблоки","Вентиляторы","Воронки","Втулки","Выключатели","Датчики, термостаты","Дверцы","Двигатели","Держатели капсул","Держатели фильтра","Заварочные блоки (диффузоры)","Замки, ключи","Заслонки","Кабели","Клапаны","Кнопки","Колбы","Контейнеры, поддоны","Корпусные детали","Кофемолки","Краны воды и пара","Крепление","Крышки","Лампы","Насосы (помпы)","Ножи","Патрубки","Платы управления","Поршни","Предохранители","Прокладки, уплотнители","Пружины","Разное","Расходомеры воды, дистрибьюторы","Редукторы","Ручки переключения","Ручки, штоки","Сито (крема-фильтры)","Сопло, насадки, капучинаторы","Средства для кофеварок и кофемашин","Трубки, переходники","Фильтры","Хомуты","Шестерни","Шнеки","Штуцеры"]},{name:"Запчасти и аксессуары для пароварок и мультиварок",children:["Влагосборники","Датчики температуры","Замок крышки","Контейнеры и емкости","Корпусные детали","Крышки","Паровые клапаны","Платы управления","Поддоны для капель","Разное","Ручки таймера","Сетевые шнуры","Таймеры","Тэны","Уплотнители","Чаши"]},{name:"Запчасти для хлебопечек",children:["Аксессуары","Ведра","Двигатели","Лопатки","Мерные стаканы и ложки","Платы (модули) управления","Привод ведра","Ремни","Сальники","Термодатчики","Термопредохранители","Трансформаторы","Тэны","Шестерни","Шкивы"]},{name:"Запчасти для грилей и аэрогрилей",children:["Аксессуары","Панели для грилей","Платы управления","Разные детали","Таймеры","Термостаты","Тэны","Чаши"]},{name:"Запчасти для мультипечей",children:["Аксессуары","Двигатели","Контейнеры","Ручки/накладки ручек для контейнеров","Сетки/Решетки","Тэны"]},{name:"Запчасти для соковыжималок",children:["Аксессуары","Выключатели","Двигатели (моторы)","Держатели сита","Защелки","Контейнеры для жмыха","Корпусные детали","Крышки корпуса","Ножи сито","Платы управления","Слив для сока","Толкатели","Цитрус-пресс","Чаши","Шнеки"]},{name:"Запчасти для кофемолок",children:["Аксессуары","Крышки","Ножи"]}]},{name:"Промышленный холод",children:[{name:"Автоматика"},{name:"Вакуумные насосы"},{name:"Вентиляторы и двигатели"},{name:"Воздухоохладители потолочные"},{name:"Инструменты для ремонта и установки оборудования"},{name:"Клапаны Шредера"},{name:"Компрессоры для холодильных установок"},{name:"Конденсаторы воздушного охлаждения"},{name:"Крепления для кондиционеров"},{name:"Масла для компрессоров кондиционеров и вакуумных насосов"},{name:"Плачущие испарители для холодильников"},{name:"Пусковые конденсаторы для кондиционеров"},{name:"Расходники для монтажа холодильного оборудования"},{name:"Ресиверы для фреона"},{name:"Смотровые стёкла для фреона"},{name:"Соленоидные вентили для холодильного оборудования"},{name:"Терморегулирующие вентили (ТРВ) кондиционера"},{name:"Термостаты для холодильного оборудования"},{name:"Труба дренажная / Сифоны для кондиционера"},{name:"Трубы медные для оборудования"},{name:"Тэны подогрева дренажа"},{name:"Фильтр-осушитель фреоновый"},{name:"Фитинги (переходники) для холодильных трубок"}]},{name:"К технике по уходу за домом и телом"},{name:"Для отопительной и водонагревательной техники"},{name:"Для климатической техники"},{name:"Запчасти HoReCa"},{name:"Для автомобильных кондиционеров",children:[{name:"Все для монтажа кондиционеров",children:["Гайки","Изоляция","Кабели","Кронштейны","Трубы","Трубы дренажные","Фреон"]},{name:"Конденсаторы"},{name:"Предохранители"},{name:"Подшипники"},{name:"Смазки для сальников и подшипников"},{name:"Фреон"}]},{name:"Средства для бытовой техники"},{name:"Молниезащита и заземление"},{name:"Батарейки"},{name:"Пульты ДУ"},{name:"ТЭНы",children:[{name:"ТЭНы для водонагревателя (бойлера)"},{name:"ТЭНы для воды"},{name:"ТЭНы для дистиллятора"},{name:"ТЭНы для духовок и гриля"},{name:"ТЭНы для калориферов, тепловентиляторов"},{name:"ТЭНы для кофеварок и кофемашин"},{name:"ТЭНы для масляных обогревателей"},{name:"ТЭНы для микроволновок"},{name:"ТЭНы для пароварок и мультиварок"},{name:"ТЭНы для полотенцесушителя"},{name:"ТЭНы для посудомоечной машины"},{name:"ТЭНы для радиаторов"},{name:"ТЭНы для стиральной машины"},{name:"ТЭНы для сушильных машин"},{name:"ТЭНы для хлебопечки"},{name:"ТЭНы оттайки для холодильника"}]},{name:"Универсальные запчасти"},{name:"Спецпредложения"}],i={а:"a",б:"b",в:"v",г:"g",д:"d",ё:"yo",ж:"zh",з:"z",и:"i",й:"y",к:"k",л:"l",м:"m",н:"n",о:"o",п:"p",р:"r",с:"s",т:"t",у:"u",ф:"f",х:"h",ц:"ts",ч:"ch",ш:"sh",щ:"shch",ъ:"",ы:"y",ь:"",э:"e",ю:"yu",я:"ya",і:"i",ї:"yi",є:"ye",ґ:"g"};function isWordBoundary(e){return!e||"ь"===e||"ъ"===e||!/[a-z0-9а-яёіїєґ]/i.test(e)}function categorySlug(e){let t=String(e||"").toLowerCase(),a="";for(let e=0;e<t.length;e+=1){let r=t[e];if("е"===r){a+=isWordBoundary(t[e-1])?"ye":"e";continue}if(Object.prototype.hasOwnProperty.call(i,r)){a+=i[r];continue}if(/[a-z0-9]/.test(r)){a+=r;continue}a+="-"}return a.replace(/-+/g,"-").replace(/^-|-$/g,"")}function nodeName(e){return"string"==typeof e?e:e?.name||""}function nodeChildren(e){return e&&"string"!=typeof e&&Array.isArray(e.children)?e.children:[]}function categoryNodes(e=r,t=""){return e.map((e,a)=>{let r=nodeName(e),i=categorySlug(r),n=t?`${t}/${i}`:i;return{name:r,slug:i,path:n,sort:a,children:categoryNodes(nodeChildren(e),n)}})}},61916:(e,t,a)=>{function parseMoney(e){if(null==e||""===e)return null;if("number"==typeof e)return!Number.isFinite(e)||e<0?null:Math.round(100*e);let t=String(e).trim().replace(/\s/g,"").replace("₴","").replace(",",".");if(!/^\d+(\.\d{1,2})?$/.test(t))return null;let[a,r=""]=t.split(".");return 100*Number(a)+Number((r+"00").slice(0,2))}function formatMoney(e){if(null==e||""===e)return"";let t=Number(e);if(!Number.isFinite(t))return"";let a=t<0?"-":"",r=Math.abs(t),i=r%100,n=Math.floor(r/100).toLocaleString("uk-UA").replace(/\u00A0/g," ");return i?`${a}₴${n},${String(i).padStart(2,"0")}`:`${a}₴${n}`}a.d(t,{a6:()=>parseMoney,lb:()=>formatMoney})},21320:(e,t,a)=>{a.a(e,async(e,r)=>{try{let p;a.d(t,{CL:()=>categoryTree,EE:()=>applyImportedProduct,Ir:()=>deleteProduct,Jo:()=>categoryBreadcrumb,QW:()=>descendantIds,RE:()=>flatCategories,d7:()=>categoriesBySuffix,gg:()=>saveProduct,go:()=>listChildCategories,i6:()=>getCategoryByPath,k4:()=>createCategory,oI:()=>findProductBySku,pk:()=>listBrands,s3:()=>searchProducts,sT:()=>getPublicProduct,uu:()=>deleteCategory,yA:()=>exportProducts,yr:()=>updateCategory});var i=a(6113),n=a(57147),o=a.n(n),c=a(71017),s=a.n(c),l=a(32704),d=a(54122),u=a(61916),m=e([l]);l=(m.then?(await m)():m)[0];let g=["in","out","order"],h=["active","inactive"];function statements(e){return e.split(/;\s*(?:\n|$)/).map(e=>e.trim()).filter(e=>e&&!e.startsWith("--"))}function newId(){return(0,i.randomBytes)(12).toString("hex")}function categoryId(e){return(0,i.createHash)("sha256").update(e).digest("hex").slice(0,24)}async function applySchema(){let e=o().readFileSync(s().join(process.cwd(),"src/db/schema.sql"),"utf8");for(let t of statements(e))await l.i.unsafe(t)}async function insertNode(e,t,a){for(let r of(await e`
    insert into categories (id, parent_id, name, slug, path, sort_order)
    values (${categoryId(t.path)}, ${a}, ${t.name}, ${t.slug}, ${t.path}, ${t.sort})
    on conflict (path) do nothing
  `,t.children))await insertNode(e,r,categoryId(t.path))}async function seedCategories(){let e=await l.i`select value from schema_meta where key = 'categories_seeded'`;e.length||await l.i.begin(async e=>{await e`select pg_advisory_xact_lock(714001)`;let t=await e`select value from schema_meta where key = 'categories_seeded'`;if(!t.length){for(let t of(0,d.bF)())await insertNode(e,t,null);await e`
      insert into schema_meta (key, value)
      values ('categories_seeded', '1')
      on conflict (key) do nothing
    `}})}function ready(){return p||(p=applySchema().then(seedCategories).catch(e=>{throw p=null,e})),p}function filenames(e,t){let a=Array.isArray(e)?e:[];return a.map(e=>"string"==typeof e?e:e?.filename).map(e=>String(e||"").trim()).filter(Boolean).filter((e,t,a)=>a.indexOf(e)===t).concat(t&&!a.length?[t]:[]).filter((e,t,a)=>a.indexOf(e)===t)}function toPublicProduct(e){let t=(0,u.lb)(e.price_amount),a=null==e.sale_price_amount?"":(0,u.lb)(e.sale_price_amount),r=filenames(e.images,e.image),i=Array.isArray(e.compatibility)?e.compatibility:[];return{id:e.id,sku:e.sku,slug:e.slug,title:e.title,brand:e.brand||"",manufacturer:e.manufacturer||"",image:e.image||r[0]||"",images:r,price:a?t:"",offer_price:a||t,price_amount:e.price_amount,sale_price_amount:e.sale_price_amount,review:0,campaingn_product:!1,cam_product_available:null,cam_product_sale:null,product_type:null,stock:e.stock_status,stock_qty:e.stock_qty,lead_time:e.lead_time||"",description:e.description||"",warranty:e.warranty||"",specs:Array.isArray(e.specs)?e.specs:[],compatibility:i,compatible:i.map(e=>[e.brand,e.model].filter(Boolean).join(" ")).join("\n"),seo_title:e.seo_title||"",seo_description:e.seo_description||"",status:e.status,category_id:e.category_id,category_chain:e.category_chain||[]}}let y=`
  select p.*,
    coalesce((
      select json_agg(json_build_object('filename', i.filename, 'alt', i.alt) order by i.sort_order, i.filename)
      from product_images i where i.product_id = p.id
    ), '[]'::json) as images,
    coalesce((
      select json_agg(json_build_object('brand', c.brand, 'model', c.model) order by c.brand, c.model)
      from product_compatibility c where c.product_id = p.id
    ), '[]'::json) as compatibility
  from products p
`;async function categoryChain(e){if(!e)return[];let t=await l.i`
    with recursive chain as (
      select id, parent_id, name, path, 0 as depth
      from categories where id = ${e}
      union all
      select c.id, c.parent_id, c.name, c.path, chain.depth + 1
      from categories c
      join chain on c.id = chain.parent_id
    )
    select name, path from chain order by depth desc
  `;return t}async function withChain(e){let t=new Map;for(let a of e)!a.category_id||t.has(a.category_id)||t.set(a.category_id,await categoryChain(a.category_id));return e.map(e=>({...e,category_chain:t.get(e.category_id)||[]}))}async function categoryTree(){await ready();let e=await l.i`
    select id, parent_id, name, slug, path, sort_order
    from categories
    order by sort_order, name
  `,t=new Map;function build(e){return(t.get(e||"")||[]).map(e=>({id:e.id,name:e.name,slug:e.slug,path:e.path,children:build(e.id)}))}return e.forEach(e=>{let a=e.parent_id||"";t.has(a)||t.set(a,[]),t.get(a).push(e)}),build("")}async function getCategoryByPath(e){await ready();let t=await l.i`
    select id, parent_id, name, slug, path
    from categories
    where path = ${e}
  `;return t[0]||null}async function categoriesBySuffix(e){return await ready(),l.i`
    select id, name, path
    from categories
    where path = ${e} or path like ${`%/${e}`}
  `}async function categoryBreadcrumb(e){return await ready(),categoryChain(e)}async function listChildCategories(e){return await ready(),l.i`
    select id, name, slug, path
    from categories
    where parent_id = ${e}
    order by sort_order, name
  `}function descendantCondition(e){return e?.length?l.i`p.category_id in ${(0,l.i)(e)}`:l.i`true`}async function descendantIds(e){await ready();let t=await l.i`
    with recursive tree as (
      select id from categories where id = ${e}
      union all
      select c.id from categories c join tree on c.parent_id = tree.id
    )
    select id from tree
  `;return t.map(e=>e.id)}function productFilters({q:e,brand:t,stock:a,min:r,max:i,status:n,categoryIds:o}){let c=e?`%${e.replace(/[%_]/g,"")}%`:null;return l.i`
    ${n?l.i`p.status = ${n}`:l.i`true`}
    ${t?l.i`and lower(p.brand) = lower(${t})`:l.i``}
    ${a?l.i`and p.stock_status = ${a}`:l.i``}
    ${null!=r?l.i`and coalesce(p.sale_price_amount, p.price_amount) >= ${r}`:l.i``}
    ${null!=i?l.i`and coalesce(p.sale_price_amount, p.price_amount) <= ${i}`:l.i``}
    ${o?.length?l.i`and ${descendantCondition(o)}`:l.i``}
    ${c?l.i`and (
            p.title ilike ${c}
            or p.sku ilike ${c}
            or p.brand ilike ${c}
            or p.manufacturer ilike ${c}
            or exists (
              select 1 from product_compatibility c
              where c.product_id = p.id and (c.model ilike ${c} or c.brand ilike ${c})
            )
          )`:l.i``}
  `}async function searchProducts(e={}){await ready();let t=Math.min(48,Math.max(1,Number(e.limit)||24)),a=Math.max(1,Number(e.page)||1),r=productFilters(e),i=await l.i`
    ${l.i.unsafe(y)}
    where ${r}
    order by p.updated_at desc
    limit ${t} offset ${(a-1)*t}
  `,n=await l.i`select count(*)::int as total from products p where ${r}`,o=(await withChain(i)).map(toPublicProduct);return{products:o,total:n[0]?.total||0,page:a,limit:t}}async function listBrands(){await ready();let e=await l.i`
    select brand, count(*)::int as total
    from products
    where status = 'active' and brand <> ''
    group by brand
    order by brand
  `;return e}async function getPublicProduct(e){await ready();let t=await l.i`
    ${l.i.unsafe(y)}
    where (p.id = ${e} or p.slug = ${e}) and p.status = 'active'
    limit 1
  `;if(!t[0])return null;let[a]=await withChain(t);return toPublicProduct(a)}async function getAdminProduct(e){await ready();let t=await l.i`
    ${l.i.unsafe(y)}
    where p.id = ${e}
    limit 1
  `;if(!t[0])return null;let[a]=await withChain(t);return toPublicProduct(a)}async function uniqueSlug(e,t,a,r){let i=(0,d.$)(t)||(0,d.$)(a)||"product",n=i,o=2;for(;;){let t=await e`
      select id from products where slug = ${n} and id is distinct from ${r}
    `;if(!t.length)return n;n=`${i}-${o}`,o+=1}}async function saveProduct(e,t){await ready();let a=String(e.title||"").trim(),r=String(e.sku||"").trim();if(!a||!r)return{error:"Вкажіть назву і артикул"};if(!Number.isInteger(e.price_amount)||e.price_amount<0)return{error:"Вкажіть коректну ціну"};if(null!=e.sale_price_amount&&(!Number.isInteger(e.sale_price_amount)||e.sale_price_amount<0))return{error:"Вкажіть коректну акційну ціну"};let i=g.includes(e.stock_status)?e.stock_status:"in",n=h.includes(e.status)?e.status:"active",o=filenames(e.images,e.image),c=(Array.isArray(e.compatibility)?e.compatibility:[]).map(e=>({brand:String(e?.brand||"").trim(),model:String(e?.model||"").trim()})).filter(e=>e.model),s=null==e.specs?null:JSON.stringify((Array.isArray(e.specs)?e.specs:[]).map(e=>({name:String(e?.name||"").trim(),value:String(e?.value||"").trim()})).filter(e=>e.name&&e.value));try{let d=await l.i.begin(async l=>{let d=await l`
        select id from products where lower(sku) = lower(${r}) and id is distinct from ${t||null}
      `;if(d.length)throw Error("Артикул уже існує");if(e.category_id){let t=await l`select id from categories where id = ${e.category_id}`;if(!t.length)throw Error("Категорію не знайдено")}let u=String(e.slug||"").trim();if(!u&&t){let e=await l`select slug from products where id = ${t}`;u=e[0]?.slug||""}u||(u=await uniqueSlug(l,a,r,t||null));let m=await l`
        select id from products where slug = ${u} and id is distinct from ${t||null}
      `;if(m.length)throw Error("Така адреса товару вже є");let p={sku:r,slug:u,title:a,category_id:e.category_id||null,brand:String(e.brand||"").trim(),manufacturer:String(e.manufacturer||"").trim(),price_amount:e.price_amount,sale_price_amount:e.sale_price_amount,stock_status:i,stock_qty:Math.max(0,Number(e.stock_qty)||0),lead_time:String(e.lead_time||"").trim(),description:String(e.description||"").trim(),warranty:String(e.warranty||"").trim(),specs:s,seo_title:String(e.seo_title||"").trim(),seo_description:String(e.seo_description||"").trim(),image:Array.isArray(e.images)||e.image?o[0]||"":null,status:n},g=t;if(t){let e=await l`
          update products set
            sku = ${p.sku},
            slug = ${p.slug},
            title = ${p.title},
            category_id = ${p.category_id},
            brand = ${p.brand},
            manufacturer = ${p.manufacturer},
            price_amount = ${p.price_amount},
            sale_price_amount = ${p.sale_price_amount},
            stock_status = ${p.stock_status},
            stock_qty = ${p.stock_qty},
            lead_time = ${p.lead_time},
            description = ${p.description},
            warranty = ${p.warranty},
            specs = coalesce(${p.specs}::jsonb, specs),
            seo_title = ${p.seo_title},
            seo_description = ${p.seo_description},
            image = coalesce(${p.image}, image),
            status = ${p.status},
            updated_at = now()
          where id = ${t}
          returning id
        `;if(!e.length)throw Error("Товар не знайдено")}else g=newId(),await l`
          insert into products (
            id, sku, slug, title, category_id, brand, manufacturer, price_amount, sale_price_amount,
            stock_status, stock_qty, lead_time, description, warranty, specs, seo_title, seo_description,
            image, status
          ) values (
            ${g}, ${p.sku}, ${p.slug}, ${p.title}, ${p.category_id},
            ${p.brand}, ${p.manufacturer}, ${p.price_amount}, ${p.sale_price_amount},
            ${p.stock_status}, ${p.stock_qty}, ${p.lead_time}, ${p.description},
            ${p.warranty}, ${p.specs??"[]"}::jsonb, ${p.seo_title}, ${p.seo_description},
            ${p.image||""}, ${p.status}
          )
        `;if(Array.isArray(e.images)||e.image){await l`delete from product_images where product_id = ${g}`;for(let e=0;e<o.length;e+=1)await l`
            insert into product_images (id, product_id, filename, sort_order)
            values (${newId()}, ${g}, ${o[e]}, ${e})
          `}if(Array.isArray(e.compatibility))for(let e of(await l`delete from product_compatibility where product_id = ${g}`,c))await l`
            insert into product_compatibility (id, product_id, brand, model)
            values (${newId()}, ${g}, ${e.brand}, ${e.model})
          `;return g});return{product:await getAdminProduct(d)}}catch(e){return{error:e.message||"Не вдалося зберегти товар"}}}async function deleteProduct(e){await ready();let t=await l.i`delete from products where id = ${e} returning id`;return t.length>0}async function createCategory({name:e,parentId:t}){await ready();let a=String(e||"").trim();if(!a)return{error:"Вкажіть назву категорії"};let r=t?(await l.i`select id, path from categories where id = ${t}`)[0]:null;if(t&&!r)return{error:"Батьківську категорію не знайдено"};let i=(0,d.$)(a),n=r?.path?`${r.path}/${i}`:i,o=await l.i`select id from categories where path = ${n}`;if(o.length)return{error:"Така адреса категорії вже є"};let c=await l.i`
    select coalesce(max(sort_order), -1) + 1 as sort
    from categories
    where parent_id is not distinct from ${t||null}
  `,s=newId();return await l.i`
    insert into categories (id, parent_id, name, slug, path, sort_order)
    values (${s}, ${t||null}, ${a}, ${i}, ${n}, ${c[0].sort})
  `,{category:{id:s,name:a,slug:i,path:n,parent_id:t||null}}}async function updateCategory(e,t){await ready();let a=String(t||"").trim();if(!a)return{error:"Вкажіть назву категорії"};let r=(await l.i`select id, parent_id, path from categories where id = ${e}`)[0];if(!r)return{error:"Категорію не знайдено"};let i=r.parent_id?(await l.i`select path from categories where id = ${r.parent_id}`)[0]:null,n=(0,d.$)(a),o=i?.path?`${i.path}/${n}`:n,c=await l.i`select id from categories where path = ${o} and id <> ${e}`;if(c.length)return{error:"Така адреса категорії вже є"};let s=await l.i`
    select id, path from categories
    where path = ${r.path} or path like ${`${r.path}/%`}
    order by length(path) desc
  `;return await l.i.begin(async t=>{for(let i of s){let n=i.path===r.path?o:`${o}${i.path.slice(r.path.length)}`,c=n.split("/").pop();i.id===e?await t`update categories set name = ${a}, slug = ${c}, path = ${n} where id = ${i.id}`:await t`update categories set slug = ${c}, path = ${n} where id = ${i.id}`}}),{ok:!0}}async function deleteCategory(e){await ready();let t=await l.i`select id from categories where parent_id = ${e} limit 1`;if(t.length)return{error:"Спочатку видаліть або перенесіть підкатегорії"};let a=await l.i`select id from products where category_id = ${e} limit 1`;if(a.length)return{error:"У категорії є товари"};let r=await l.i`delete from categories where id = ${e} returning id`;return r.length?{ok:!0}:{error:"Категорію не знайдено"}}async function flatCategories(){return await ready(),l.i`
    select id, parent_id, name, slug, path
    from categories
    order by path
  `}async function findProductBySku(e){await ready();let t=await l.i`select id, slug from products where lower(sku) = lower(${e}) limit 1`;return t[0]||null}async function applyImportedProduct(e){return saveProduct(e.input,e.existingId||null)}async function exportProducts(){await ready();let e=await l.i`
    ${l.i.unsafe(y)}
    order by p.sku
  `,t=await withChain(e);return t.map(e=>{let t=filenames(e.images,e.image),a=Array.isArray(e.specs)?e.specs:[],r=Array.isArray(e.compatibility)?e.compatibility:[];return{sku:e.sku,title:e.title,slug:e.slug,category_id:e.category_id,category_path:(e.category_chain||[]).map(e=>e.name),price_amount:e.price_amount,sale_price_amount:e.sale_price_amount,stock_status:e.stock_status,stock_qty:e.stock_qty,lead_time:e.lead_time||"",brand:e.brand||"",manufacturer:e.manufacturer||"",warranty:e.warranty||"",description:e.description||"",specs:a,image:t[0]||"",status:e.status,seo_title:e.seo_title||"",seo_description:e.seo_description||"",product_images:t.map((e,t)=>({filename:e,sort_order:t+1})),product_compatibility:r}})}r()}catch(e){r(e)}})}};